import UI.Header;

import Repository.MyBookRepository;
import Repository.MyBookRepositoryImpl;

import Service.MyBookService;
import Service.MyBookServiceImpl;

import javax.swing.UIManager;
import com.formdev.flatlaf.FlatIntelliJLaf;


public class App_k7_11S22030 {
   
    public static void main(String[] args) {
        
        try {
            UIManager.setLookAndFeel(new FlatIntelliJLaf());
        } catch (Exception ex) {
            System.out.println("Gagal mengubah desain tampilan");
        }
    
        
            MyBookRepository myBookRepository = new MyBookRepositoryImpl();
            MyBookService myBookService = new MyBookServiceImpl(myBookRepository);
            Header header = new Header();
            
            header.setMyBookService(myBookService); 
            myBookService.setTableMyBook(header.getTable());
            myBookService.showMyBooks(null, null, 0);
            
            header.setVisible(true);
        

    }
}
