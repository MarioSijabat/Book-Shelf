package Repository;
import Entity.MyBook;
import java.util.ArrayList;

//cek dlu database nya!!
public interface MyBookRepository {

    ArrayList<MyBook> getAll();

    ArrayList<MyBook> getNonArchived();

    ArrayList<MyBook> getArchived();
    
    ArrayList<MyBook> getUpdateArchived(Integer isbn, boolean isArchived);
    
//untuk tambahan
    boolean FavMyBook (Integer isbn, boolean isfavorite);
    
    boolean updateArchived (Integer isbn, boolean isArchived); //
    
    MyBook getWithIsbn (Integer isbn);

    boolean addMyBook (MyBook myBook);

    boolean removeMyBook (Integer isbn);

    boolean updateRead (Integer isbn, Integer currentPages);
    
//unntuk tmbahan
    ArrayList<MyBook> search (ArrayList<MyBook> data, String keywords);

}