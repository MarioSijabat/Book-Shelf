package Repository;

import Entity.MyBook;

import java.util.ArrayList;

import java.sql.ResultSet;

import java.sql.SQLException;

import Utils.DB;


public class MyBookRepositoryImpl implements MyBookRepository {

    private final DB db;

    public MyBookRepositoryImpl() {
        db = new DB();
    }
    
    public ArrayList<MyBook> array = new ArrayList<>();

    //right
    @Override
    public ArrayList<MyBook> getAll() {
        ArrayList<MyBook> bookList = new ArrayList<>();
//query, cari
        String query = "SELECT * FROM myBook";
        
        //set dr db
        ResultSet resultSet = db.get(query, null); //kenapa set value null?
        if (resultSet != null) {
            try {
                while (resultSet.next()) {
                    int isbn = resultSet.getInt("isbn");
                    String judul = resultSet.getString("judul");
                    String penulis = resultSet.getString("penulis");
                    String penerbit = resultSet.getString("penerbit");
                    int tahun = resultSet.getInt("tahun");
                    int currentPages = resultSet.getInt("sekarang");
                    int totalPages = resultSet.getInt("total");
                    boolean status = resultSet.getBoolean("status");
                    boolean fav = resultSet.getBoolean("favorite");
                    //otw buat note
                    //perhatikan semua
                    MyBook myBook = new MyBook(isbn,judul, penulis, penerbit, tahun, currentPages, totalPages, status, fav)
                            ;
                    bookList.add(myBook);
                }
            } catch (SQLException ex) {
                // Handle SQLException
            }
        }

        return bookList;
    }
    
    @Override
    public ArrayList<MyBook> getUpdateArchived(Integer isbn, boolean isArchive) {
    ArrayList<MyBook> updateArchived = new ArrayList<>();
    
    return updateArchived;
    }

    //follow
    @Override
public ArrayList<MyBook> getNonArchived() {
    ArrayList<MyBook> nonArchivedList = new ArrayList<>();

    if (array.isEmpty()) {
        return nonArchivedList;
    } else {
        //gmna
        for (MyBook book : array) {
            if (!book.isArchived()) {
                nonArchivedList.add(book);
            }
        }
    }

    return nonArchivedList;
}

//biar tau mana arsip, cek dlu ksong
@Override
public ArrayList<MyBook> getArchived() {
    ArrayList<MyBook> archivedList = new ArrayList<>();

    if (array.isEmpty()) {
        return archivedList;
    } else {
        for (MyBook book : array) {
            if (book.isArchived()) {
                archivedList.add(book);
            }
        }
    }

    return archivedList;
}



//right
@Override
public MyBook getWithIsbn(Integer isbn) {
    ArrayList<MyBook> data = getAll();
//gmn, dmn
    for (MyBook myBook : data) {
        if (myBook.getIsbn().equals(isbn)) {
            return myBook;
        }
    }
    return null;
}

//cari tahu
@Override
public boolean addMyBook(MyBook myBook) {
    ArrayList<MyBook> existingBooks = getAll();
    System.out.println(myBook);

    if (isBookInList(existingBooks, myBook.getIsbn()) || !isValidBook(myBook)) {
        return false;
    }

    String query = "INSERT INTO myBook (isbn, judul, penulis, penerbit, tahun, sekarang, total, status, favorite) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
    String status = myBook.isArchived() ? "1" : "0";
    String favorite = myBook.isFavorite() ? "1" : "0";
    
    String[] values = new String[]{
            String.valueOf(myBook.getIsbn()),
            myBook.getJudul(),
            myBook.getPenulis(),
            myBook.getPenerbit(),
            String.valueOf(myBook.getTahun()),
            String.valueOf(myBook.getCurrentPages()),
            String.valueOf(myBook.getTotalPages()),
            status,
            favorite,
    };

    return db.update(query, values);
}
//gmna
private boolean isBookInList(ArrayList<MyBook> bookList, Integer isbn) {
    for (MyBook book : bookList) {
        if (book.getIsbn().equals(isbn)) {
            return true;
        }
    }
    return false;
}

private boolean isValidBook(MyBook myBook) {
    return myBook.getIsbn() != null && 
           myBook.getJudul() != null &&
           myBook.getPenulis() != null && 
           myBook.getPenerbit() != null &&
           myBook.getTahun() != null && 
           myBook.getTotalPages() != null;
}

//right
    @Override
    public boolean removeMyBook(Integer isbn) {

        String query = "DELETE FROM myBook WHERE isbn = ?";
       
        
        //cari tahu 
        String[] values = new String[]{String.valueOf(isbn)};
        
        return db.update(query, values);

    }

//right
    @Override
    public boolean updateRead (Integer isbn, Integer currentPages) {
        //mencurigakans
        String query = "UPDATE myBook SET sekarang = CASE WHEN ? <= total THEN ?" 
                + "    ELSE sekarang END WHERE isbn = ?";


        String[] values = new String[]{String.valueOf(currentPages), String.valueOf(currentPages), String.valueOf(isbn)};
        System.out.println(values);
        
        return db.update(query, values);
    }
    
//untuk favorite
/*
@override
public boolean updateFavorite (Integer isbn, boolean isFavorite) {
    String query = "UPDATE myBook SET favorite = ? WHERE isbn = ?";

        String status;
        if (isFavorite) {
            status = "1";
        } else {
            status = "0";
        }
        
        String[] values = new String[]{String.valueOf(status), String.valueOf(isbn)};
        return db.update(query, values);
    }   
    */
    
//untuk favorite
    @Override
    public boolean FavMyBook (Integer isbn, boolean isFavorite) {
    String query = "UPDATE myBook SET favorite = ? WHERE isbn = ?";

        String status;
        if (isFavorite) {
            status = "1";
        } else {
            status = "0";
        }
        
        String[] values = new String[]{String.valueOf(status), String.valueOf(isbn)};
        return db.update(query, values);
    }   
    
//belum berani
    //buat tombol biar set as archived
    @Override
    public boolean updateArchived(Integer isbn, boolean isArchived) {
/*    String query = "UPDATE myBook SET status = ? WHERE isbn = ?";
    
    int status = isArchived ? 1 : 0;

    try (Connection connection = DriverManager.getConnection("jdbc:mariadb://localhost:3306/myBookShelfPBO", "root", "root");
         PreparedStatement preparedStatement = connection.prepareStatement(query)) {

        preparedStatement.setInt(1, status);
        preparedStatement.setInt(2, isbn);

        int rowsUpdated = preparedStatement.executeUpdate();

        return rowsUpdated > 0;
    } catch (SQLException e) {
        e.printStackTrace(); // Handle the exception according to your needs
        return false;
    }
}*/
       String query = "UPDATE myBook SET status = ? WHERE isbn = ?";

        String status;
        if (isArchived) {
            status = "1";
        } else {
            status = "0";
        }
        
        String[] values = new String[]{String.valueOf(status), String.valueOf(isbn)};
        return db.update(query, values);
    }


   
    //coba cari cara nya di praktikkum lain
    //cek ada ga keywrd nya
    
    @Override
public ArrayList<MyBook> search(ArrayList<MyBook> data, String keywords) {

    ArrayList<MyBook> searchResults = new ArrayList<>();


        for (MyBook book : data) {
            if (book.getJudul().contains(keywords)) {
                searchResults.add(book);
            } else {
                searchResults.add(null);
            }
        }
        
    


    return searchResults;
}




    
}