package UI.Pages;

public class PagesController {

    public static HeaderButton butt = new HeaderButton();
    
}
