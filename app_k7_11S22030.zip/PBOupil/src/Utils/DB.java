package Utils;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class DB {

    private final String url
            = "jdbc:mariadb://localhost:3306/myBookShelfPBO";
    private final String username = "root";
    private final String password = "root";
    private Connection connection;

    private Statement statement;

    public DB() {
        init();
    }

    private void init() {
        try {
            this.connection = DriverManager.getConnection(url,
                    username, password);
            this.statement = this.connection.createStatement();
        } catch (SQLException ex) {
            System.out.println("Gagal terkoneksi ke Database");
        }
    }

    public ResultSet get(String query, String[] values) {
        try {
            if (values != null) {
                PreparedStatement preparedStatement
                        = connection.prepareStatement(query);
                for (int i = 0; i < values.length; i++) {
                    preparedStatement.setString(i + 1, values[i]);
                }
                return preparedStatement.executeQuery(query);
            } else {
                return statement.executeQuery(query);
            }
        } catch (SQLException ex) {
            return null;
        }
    }

    public boolean update(String query, String[] values) {
        
        try {
            System.out.println("10%");
            PreparedStatement preparedStatement
                    = connection.prepareStatement(query);
            if (values != null) {
                System.out.println("30%");
                for (int i = 0; i < values.length; i++) {
                    
                    preparedStatement.setString(i + 1, values[i]);
                    
                }
                System.out.println("40%");
            }
            
            System.out.println(preparedStatement);
            preparedStatement.executeUpdate();
               
            
            return true;
        } catch (SQLException ex) {
            return false;
        }
    }
}
