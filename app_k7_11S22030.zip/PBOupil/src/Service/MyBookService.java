package Service;


import Entity.MyBook;
import javax.swing.JTable;

public interface MyBookService {
    
    public boolean readMyBook (Integer isbn);

    public void showMyBooks(Integer ISBN, String keywords, Integer status);    
    
    public void loadData(Integer ISBN, String keywords, Integer status);
    
    public void setColor(Integer Color);
    
    public void tableHandling();
    
    public void setTableMyBook (JTable tblMyBook);
    
    public void addMyBooks(Integer isbn, String judul, String penulis, String penerbit, Integer tahun, Integer totalPages);

    public void removeMyBooks(Integer isbn, Integer searchIsbn, String keywords, Integer status);

    public void updateReadingMyBook(Integer isbn, String keywords, Integer status, Integer currentPages);

    public void updateArchivedMyBook(Integer isbn, boolean isArchived);
    
    public void updateFavoriteMyBook (Integer isbn, boolean isFavorite);
    
    public void searchMyBookShelf(String keywords); 

    public MyBook getIsbn(Integer isbn);

}