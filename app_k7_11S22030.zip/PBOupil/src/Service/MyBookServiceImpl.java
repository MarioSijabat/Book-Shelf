package Service;
//right

import Entity.MyBook;
import Repository.MyBookRepository;
import java.awt.Color;
import java.awt.Component;
import java.awt.Frame;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.DataBufferShort;
import java.util.ArrayList;
import java.util.EventObject;
import java.util.Objects;
import javax.swing.DefaultCellEditor;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.event.CellEditorListener;
import javax.swing.event.ChangeEvent;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableCellRenderer;
import javax.swing.table.TableColumn;
import javax.swing.table.TableColumnModel;
import javax.swing.text.DefaultEditorKit;
import javax.swing.text.StyleConstants;

public class MyBookServiceImpl implements MyBookService {

    private MyBookRepository myBookRepository;
    private Integer Color = 0;
    private JTable tblMyBook;

    @Override
    public void setTableMyBook(JTable tblMyBook) {
        this.tblMyBook = tblMyBook;

    }

    public MyBookServiceImpl(MyBookRepository myBookRepository) {

        this.myBookRepository = myBookRepository;

    }

    @Override
    public boolean readMyBook(Integer book_number) {
        MyBook myBook = myBookRepository.getWithIsbn(book_number);
        return false;
    }

    @Override
    public void showMyBooks(Integer ISBN, String keywords, Integer status)//Integer favorite
    {
        tableHandling();
        loadData(ISBN, keywords, status); //favorite

    }

    @Override
    public void addMyBooks(Integer isbn, String judul, String penulis, String penerbit, Integer tahun, Integer totalPages) {

        MyBook myBook = new MyBook(isbn, judul, penulis, penerbit, tahun, 0, totalPages, false, false);

        boolean success = myBookRepository.addMyBook(myBook);

        if (success) {
            System.out.println("SUKSES MENAMBAH myBook ");
        } else {
            System.out.println("GAGAL MENAMBAH myBook : isbn sudah ada");
            //posisi, tulisan,title,tipe panel
            JOptionPane.showMessageDialog(null, "Isbn sudah ada!", "Error", JOptionPane.ERROR_MESSAGE);

        }

        showMyBooks(null, null, 0);//0
    }

    @Override
    public void removeMyBooks(Integer isbn, Integer searchIsbn, String keywords, Integer status) //Integer favorite
    {
        System.out.println("sukses1");

        boolean success = myBookRepository.removeMyBook(isbn);

        System.out.println("sukses2");
        MyBook myBook = myBookRepository.getWithIsbn(isbn);

        System.out.println("sukses3");
        showMyBooks(searchIsbn, keywords, status);//favorite

        System.out.println("sukses4");
    }

    @Override
    public void updateFavoriteMyBook(Integer book_number, boolean isFavorite) {
        boolean bool = false;

        ArrayList<MyBook> array = myBookRepository.getAll();

        for (MyBook book : array) {

            if (Objects.equals(book.getIsbn(), book_number)) {

                bool = myBookRepository.FavMyBook(book_number, isFavorite);

                break;
            }
        }

    }

    @Override
    public void updateReadingMyBook(Integer isbn, String keywords, Integer status, Integer currentPages) {

        MyBook myBook = myBookRepository.getWithIsbn(isbn);
        boolean result = myBookRepository.updateRead(isbn, currentPages);

    }

    //
    @Override
    public void updateArchivedMyBook(Integer isbn, boolean isArchived) {
        //set false
        boolean bool = false;

        ArrayList<MyBook> array = myBookRepository.getAll();

        for (MyBook book : array) {

            if (Objects.equals(book.getIsbn(), isbn)) {

                bool = myBookRepository.updateArchived(isbn, isArchived);

                break;
            }
        }

    }

    @Override
    public void loadData(Integer ISBN, String keywords, Integer status)//Integer favorite
    {
        ArrayList<MyBook> myBookShelf = myBookRepository.getAll();

        DefaultTableModel tableModel = new DefaultTableModel(null, new Object[]{"isbn", "judul", "penulis", "Penerbit", "Total"}) {

            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        tblMyBook.setModel(tableModel);
        tblMyBook.setCellSelectionEnabled(false);
        tblMyBook.setRowSelectionAllowed(true);
        tblMyBook.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
        tblMyBook.setRowHeight(40);

        TableColumnModel columnModel = tblMyBook.getColumnModel();

        setPreferredWidth(columnModel.getColumn(0), 100);
        setPreferredWidth(columnModel.getColumn(1), 500);
        setPreferredWidth(columnModel.getColumn(2), 200);
        setPreferredWidth(columnModel.getColumn(3), 200);
        setPreferredWidth(columnModel.getColumn(4), 130);

        if (!myBookShelf.isEmpty()) {
            for (MyBook myBook : myBookShelf) {
                if ((status == 0 && !myBook.isArchived()) || (status == 1 && myBook.isArchived())) {
                    boolean condition1 = (keywords != null && myBook.getJudul().contains(keywords));
                    boolean condition2 = (ISBN == null && keywords == null && !myBook.isArchived());
                    boolean condition3 = (Objects.equals(myBook.getIsbn(), ISBN) && !myBook.isArchived());

                    System.out.println(Color);
                    Object[] rowData = {myBook.getIsbn(), myBook.getJudul(), myBook.getPenulis(), myBook.getPenerbit(), myBook.getCurrentPages() + "/" + myBook.getTotalPages()};

                    for (int i = 0; i < rowData.length; i++) {
                        if (Color == 1) {
                            System.out.println("wrna1");
                            CustomTableCellRenderer renderer = new CustomTableCellRenderer(new Color(14, 113, 235));
                            Component component = renderer.getTableCellRendererComponent(tblMyBook, rowData[i], false, false, 0, i);
                            tblMyBook.getColumn(tblMyBook.getColumnName(i)).setCellRenderer((TableCellRenderer) component);
                        } else if (Color == 2) {
                            System.out.println("wrn2");
                            CustomTableCellRenderer renderer = new CustomTableCellRenderer(new Color(140, 45, 235));
                            Component component = renderer.getTableCellRendererComponent(tblMyBook, rowData[i], false, false, 0, i);
                            tblMyBook.getColumn(tblMyBook.getColumnName(i)).setCellRenderer((TableCellRenderer) component);
                        } else if (Color == 3) {
                            System.out.println("warna3");
                            CustomTableCellRenderer renderer = new CustomTableCellRenderer(new Color(123, 113, 235));
                            Component component = renderer.getTableCellRendererComponent(tblMyBook, rowData[i], false, false, 0, i);
                            tblMyBook.getColumn(tblMyBook.getColumnName(i)).setCellRenderer((TableCellRenderer) component);
                        } else if (Color == 4) {
                            System.out.println("warna4");
                            CustomTableCellRenderer renderer = new CustomTableCellRenderer(new Color(200, 113, 235));
                            Component component = renderer.getTableCellRendererComponent(tblMyBook, rowData[i], false, false, 0, i);
                            tblMyBook.getColumn(tblMyBook.getColumnName(i)).setCellRenderer((TableCellRenderer) component);
                        } else {
                            System.out.println("wrna5");
                            CustomTableCellRenderer renderer = new CustomTableCellRenderer(new Color(129, 113, 35));
                            Component component = renderer.getTableCellRendererComponent(tblMyBook, rowData[i], false, false, 0, i);
                            tblMyBook.getColumn(tblMyBook.getColumnName(i)).setCellRenderer((TableCellRenderer) component);
                        }
                    }

                    if ((condition1 || condition2 || condition3) && !myBook.isArchived()) {
                        System.out.println("Sukses");
                        tableModel.addRow(new Object[]{myBook.getIsbn(), myBook.getJudul(), myBook.getPenulis(), myBook.getPenerbit(), myBook.getCurrentPages() + "/" + myBook.getTotalPages()});
                    } else if ((keywords == null && ISBN == null && myBook.isArchived()) || (Objects.equals(myBook.getIsbn(), ISBN) && myBook.isArchived())) {
                        System.out.println("Sukses");
                        tableModel.addRow(new Object[]{myBook.getIsbn(), myBook.getJudul(), myBook.getPenulis(), myBook.getPenerbit(), myBook.getCurrentPages() + "/" + myBook.getTotalPages()});
                    }
                }
            }
        }
    }

// Fungsi utilitas untuk mengatur lebar preferensi kolom
    private void setPreferredWidth(TableColumn column, int width) {
        column.setPreferredWidth(width);
    }

    @Override
    public void tableHandling() {
        try {
            JTable tblMyBook = this.tblMyBook;
            tblMyBook.getColumnModel().getColumn(0).setCellEditor(new DefaultCellEditor(new JTextField()) {
                @Override
                public boolean isCellEditable(EventObject anEvent) {
                    return false;
                }
            });
            tblMyBook.getColumnModel().getColumn(4).setCellEditor(new DefaultCellEditor(new JTextField()) {
                @Override
                public boolean isCellEditable(EventObject anEvent) {
                    return false;
                }
            });
            {

                // Menambahkan CellEditorListener untuk menangkap perubahan pada kolom di JTable
                tblMyBook.getDefaultEditor(String.class
                ).addCellEditorListener(new CellEditorListener() {
                    @Override
                    public void editingStopped(ChangeEvent e) {

                        int row = tblMyBook.getSelectedRow();
                        int collumn = tblMyBook.getSelectedColumn();

                        if (collumn == 1 || collumn == 2 || collumn == 3) {

                        }

                    }

                    @Override
                    public void editingCanceled(ChangeEvent e) {
                        // aksi jika pengiditan dibatalkan
                    }
                }
                );
            }
        } catch (Error e) {

        } catch (Exception e) {

        }
    }

    //buat warna and projek
    public class CustomTableCellRenderer extends DefaultTableCellRenderer {

        private Color backgroundColor;

        public CustomTableCellRenderer(Color backgroundColor) {
            this.backgroundColor = backgroundColor;
            setOpaque(true);  // Make sure the component is opaque
        }

        @Override
        public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
            super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
            setBackground(backgroundColor);
            return this;
        }
    }

    //(tambahan)search dlu ga si
    @Override
    public void searchMyBookShelf(String keywords) {
        ArrayList<MyBook> Data = myBookRepository.getAll();

        if (keywords != null) {
            myBookRepository.search(Data, keywords);
        }
        System.out.println("10%");
        if (keywords == null) {
            myBookRepository.search(Data, null);
        }
    }

    //buat method warna, biar bisa dipake variable nya
    @Override
    public void setColor(Integer Color) {
        this.Color = Color;
        System.out.println(Color);
    }

    @Override
    public MyBook getIsbn(Integer isbn) {
        return myBookRepository.getWithIsbn(isbn);
    }

}
