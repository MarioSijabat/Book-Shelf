package Entity;

public class MyBook {

    private Integer Isbn;
    private String Judul;
    private String penulis;
    private String penerbit;
    private String Note;
    private Integer tahun;
    private Integer totalPages;
    private Integer currentPages = 0;
    private boolean isArchived = false;
    private boolean isFavorite = false;
    
//otw buat fitur catatan(note)

    public MyBook (Integer Isbn, String Judul, String penulis, String penerbit, Integer tahun, Integer currentPages, Integer totalPages, boolean isArchived, boolean isFavorite) 
    {
        this.Isbn = Isbn;
        this.Judul = Judul;
        this.penulis = penulis;
        this.penerbit = penerbit;
        this.tahun = tahun;
        this.currentPages = currentPages;
        this.totalPages = totalPages;
        this.isArchived = isArchived;
        this.isFavorite = isArchived;
       //otw note

    }
    
    public MyBook() {
    }
    
    public Integer getIsbn() {
        return Isbn;
    }

    public String getJudul() {
        return Judul;
    }
    
    public String getPenulis() {
        return penulis;
    }
    
    public String getPenerbit() {
        return penerbit;
    }
    
        //tmbahan
    public boolean isFavorite(){
        return isFavorite;
    }
    //tamabahan
    public void setFavorite(boolean isFavorite) {
    this.isFavorite = isFavorite;
    }
    
    public String getNotes(){
        return Note;
    }
    
    public Integer getTahun() {
        return tahun;
    }
    //get untuk tempat penampungan
    public Integer getTotalPages() {
        return totalPages;
    }
    
    public Integer getCurrentPages() {
        return currentPages;
    }
    
    //set biar nilainya itu berisi get tadi
    public void setCurrentPages(Integer currentPages) {
    this.currentPages = currentPages;
    }

    public boolean isArchived() {
        return isArchived;
    }

    public void setArchived(boolean isArchived) {
        this.isArchived = isArchived;
    }
    
}